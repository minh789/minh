﻿namespace MilkTea_TâyTây
{
    partial class MilkTea
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MilkTea));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pnMilkTea = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.btnMon5 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.btnMon6 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.btnMon2 = new System.Windows.Forms.Button();
            this.btnMon4 = new System.Windows.Forms.Button();
            this.btnMon1 = new System.Windows.Forms.Button();
            this.btnMon3 = new System.Windows.Forms.Button();
            this.pnMilkTea.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(-1, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(218, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Trà sữa truyền thống ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(294, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(179, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Trà sữa mặt măm";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(610, 1);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(184, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Trà sữa  măm cây";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(14, 330);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(182, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "Trà sữa niền răng";
            // 
            // pnMilkTea
            // 
            this.pnMilkTea.AutoScroll = true;
            this.pnMilkTea.BackColor = System.Drawing.Color.Yellow;
            this.pnMilkTea.Controls.Add(this.label8);
            this.pnMilkTea.Controls.Add(this.panel2);
            this.pnMilkTea.Controls.Add(this.label7);
            this.pnMilkTea.Controls.Add(this.btnMon5);
            this.pnMilkTea.Controls.Add(this.label6);
            this.pnMilkTea.Controls.Add(this.btnMon6);
            this.pnMilkTea.Controls.Add(this.label5);
            this.pnMilkTea.Controls.Add(this.btnMon2);
            this.pnMilkTea.Controls.Add(this.btnMon4);
            this.pnMilkTea.Controls.Add(this.label4);
            this.pnMilkTea.Controls.Add(this.btnMon1);
            this.pnMilkTea.Controls.Add(this.label1);
            this.pnMilkTea.Controls.Add(this.btnMon3);
            this.pnMilkTea.Controls.Add(this.label2);
            this.pnMilkTea.Controls.Add(this.label3);
            this.pnMilkTea.Location = new System.Drawing.Point(-2, -1);
            this.pnMilkTea.Name = "pnMilkTea";
            this.pnMilkTea.Size = new System.Drawing.Size(962, 592);
            this.pnMilkTea.TabIndex = 9;
            this.pnMilkTea.Paint += new System.Windows.Forms.PaintEventHandler(this.pnMilkTea_Paint);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(477, 358);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 25);
            this.label8.TabIndex = 15;
            this.label8.Text = "Best celler";
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(482, 300);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 25);
            this.panel2.TabIndex = 14;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(315, 265);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(143, 25);
            this.label7.TabIndex = 13;
            this.label7.Text = "Món đặc biệt:";
            // 
            // btnMon5
            // 
            this.btnMon5.BackColor = System.Drawing.Color.White;
            this.btnMon5.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources._003_bubble_tea_21;
            this.btnMon5.ForeColor = System.Drawing.Color.Cornsilk;
            this.btnMon5.Location = new System.Drawing.Point(278, 318);
            this.btnMon5.Name = "btnMon5";
            this.btnMon5.Size = new System.Drawing.Size(198, 244);
            this.btnMon5.TabIndex = 12;
            this.btnMon5.UseVisualStyleBackColor = false;
            this.btnMon5.Click += new System.EventHandler(this.btnMon5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(294, 290);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(172, 25);
            this.label6.TabIndex = 11;
            this.label6.Text = "Trà sữa Tây Tây";
            // 
            // btnMon6
            // 
            this.btnMon6.BackColor = System.Drawing.Color.White;
            this.btnMon6.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.tra_sua_tuoi_cuoi;
            this.btnMon6.ForeColor = System.Drawing.Color.Cornsilk;
            this.btnMon6.Location = new System.Drawing.Point(649, 350);
            this.btnMon6.Name = "btnMon6";
            this.btnMon6.Size = new System.Drawing.Size(103, 169);
            this.btnMon6.TabIndex = 10;
            this.btnMon6.UseVisualStyleBackColor = false;
            this.btnMon6.Click += new System.EventHandler(this.btnMon6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(628, 322);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(179, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "Trà sữa  tười cười";
            // 
            // btnMon2
            // 
            this.btnMon2.BackColor = System.Drawing.Color.White;
            this.btnMon2.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources._004_bubble_tea_3;
            this.btnMon2.ForeColor = System.Drawing.Color.Cornsilk;
            this.btnMon2.Location = new System.Drawing.Point(299, 29);
            this.btnMon2.Name = "btnMon2";
            this.btnMon2.Size = new System.Drawing.Size(130, 204);
            this.btnMon2.TabIndex = 4;
            this.btnMon2.UseVisualStyleBackColor = false;
            this.btnMon2.Click += new System.EventHandler(this.btnMon2_Click);
            // 
            // btnMon4
            // 
            this.btnMon4.BackColor = System.Drawing.Color.White;
            this.btnMon4.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.tra_sua_nien_rang;
            this.btnMon4.ForeColor = System.Drawing.Color.Cornsilk;
            this.btnMon4.Location = new System.Drawing.Point(29, 358);
            this.btnMon4.Name = "btnMon4";
            this.btnMon4.Size = new System.Drawing.Size(96, 161);
            this.btnMon4.TabIndex = 8;
            this.btnMon4.UseVisualStyleBackColor = false;
            this.btnMon4.Click += new System.EventHandler(this.btnMon4_Click);
            // 
            // btnMon1
            // 
            this.btnMon1.BackColor = System.Drawing.Color.White;
            this.btnMon1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMon1.BackgroundImage")));
            this.btnMon1.ForeColor = System.Drawing.Color.Cornsilk;
            this.btnMon1.Location = new System.Drawing.Point(29, 29);
            this.btnMon1.Name = "btnMon1";
            this.btnMon1.Size = new System.Drawing.Size(121, 204);
            this.btnMon1.TabIndex = 0;
            this.btnMon1.UseVisualStyleBackColor = false;
            this.btnMon1.Click += new System.EventHandler(this.btnMon1_Click);
            // 
            // btnMon3
            // 
            this.btnMon3.BackColor = System.Drawing.Color.White;
            this.btnMon3.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.tra_sua_mam_cay;
            this.btnMon3.ForeColor = System.Drawing.Color.Cornsilk;
            this.btnMon3.Location = new System.Drawing.Point(615, 29);
            this.btnMon3.Name = "btnMon3";
            this.btnMon3.Size = new System.Drawing.Size(187, 204);
            this.btnMon3.TabIndex = 6;
            this.btnMon3.UseVisualStyleBackColor = false;
            this.btnMon3.Click += new System.EventHandler(this.btnMon3_Click);
            // 
            // MilkTea
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(956, 574);
            this.Controls.Add(this.pnMilkTea);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MilkTea";
            this.Text = "Trà Sữa";
            this.pnMilkTea.ResumeLayout(false);
            this.pnMilkTea.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMon1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnMon2;
        private System.Windows.Forms.Button btnMon3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnMon4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel pnMilkTea;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnMon5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnMon6;
        private System.Windows.Forms.Label label5;
    }
}