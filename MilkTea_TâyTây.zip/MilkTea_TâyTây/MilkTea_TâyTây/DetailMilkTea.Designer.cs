﻿namespace MilkTea_TâyTây
{
    partial class DetailMilkTea
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.lbTopping7 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
            this.lbTopping6 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
            this.lbTopping5 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.lbTopping4 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.lbTopping3 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.lbTopping2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.lbTopping1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnSizeL = new System.Windows.Forms.Button();
            this.btnSizeM = new System.Windows.Forms.Button();
            this.lbSize = new System.Windows.Forms.Label();
            this.btnSizeS = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pnPercentIce = new System.Windows.Forms.Panel();
            this.rdbPercentIce3 = new System.Windows.Forms.RadioButton();
            this.rdbPercentIce2 = new System.Windows.Forms.RadioButton();
            this.rdbPercentIce1 = new System.Windows.Forms.RadioButton();
            this.pnPercentSugar = new System.Windows.Forms.Panel();
            this.rdbPercentSugar4 = new System.Windows.Forms.RadioButton();
            this.rdbPercentSugar3 = new System.Windows.Forms.RadioButton();
            this.rdbPercentSugar2 = new System.Windows.Forms.RadioButton();
            this.rdbPercentSugar1 = new System.Windows.Forms.RadioButton();
            this.lbIce = new System.Windows.Forms.Label();
            this.lbSugar = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.pnPercentIce.SuspendLayout();
            this.pnPercentSugar.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(3, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(268, 446);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(-94, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(457, 446);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.textBox7);
            this.panel3.Controls.Add(this.numericUpDown7);
            this.panel3.Controls.Add(this.lbTopping7);
            this.panel3.Controls.Add(this.textBox6);
            this.panel3.Controls.Add(this.numericUpDown6);
            this.panel3.Controls.Add(this.lbTopping6);
            this.panel3.Controls.Add(this.textBox5);
            this.panel3.Controls.Add(this.numericUpDown5);
            this.panel3.Controls.Add(this.lbTopping5);
            this.panel3.Controls.Add(this.textBox4);
            this.panel3.Controls.Add(this.numericUpDown4);
            this.panel3.Controls.Add(this.lbTopping4);
            this.panel3.Controls.Add(this.textBox3);
            this.panel3.Controls.Add(this.numericUpDown3);
            this.panel3.Controls.Add(this.lbTopping3);
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Controls.Add(this.numericUpDown2);
            this.panel3.Controls.Add(this.lbTopping2);
            this.panel3.Controls.Add(this.textBox1);
            this.panel3.Controls.Add(this.numericUpDown1);
            this.panel3.Controls.Add(this.lbTopping1);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Location = new System.Drawing.Point(3, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(649, 443);
            this.panel3.TabIndex = 1;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(509, 375);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 22);
            this.textBox7.TabIndex = 25;
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.Location = new System.Drawing.Point(383, 374);
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.Size = new System.Drawing.Size(120, 22);
            this.numericUpDown7.TabIndex = 24;
            // 
            // lbTopping7
            // 
            this.lbTopping7.AutoSize = true;
            this.lbTopping7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTopping7.Location = new System.Drawing.Point(160, 367);
            this.lbTopping7.Name = "lbTopping7";
            this.lbTopping7.Size = new System.Drawing.Size(189, 29);
            this.lbTopping7.TabIndex = 23;
            this.lbTopping7.Text = "Thạch trái cây :";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(509, 306);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 22);
            this.textBox6.TabIndex = 22;
            // 
            // numericUpDown6
            // 
            this.numericUpDown6.Location = new System.Drawing.Point(383, 307);
            this.numericUpDown6.Name = "numericUpDown6";
            this.numericUpDown6.Size = new System.Drawing.Size(120, 22);
            this.numericUpDown6.TabIndex = 21;
            // 
            // lbTopping6
            // 
            this.lbTopping6.AutoSize = true;
            this.lbTopping6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTopping6.Location = new System.Drawing.Point(160, 299);
            this.lbTopping6.Name = "lbTopping6";
            this.lbTopping6.Size = new System.Drawing.Size(199, 29);
            this.lbTopping6.TabIndex = 20;
            this.lbTopping6.Text = "Thạch phô mai :";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(509, 242);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 22);
            this.textBox5.TabIndex = 19;
            // 
            // numericUpDown5
            // 
            this.numericUpDown5.Location = new System.Drawing.Point(383, 242);
            this.numericUpDown5.Name = "numericUpDown5";
            this.numericUpDown5.Size = new System.Drawing.Size(120, 22);
            this.numericUpDown5.TabIndex = 18;
            // 
            // lbTopping5
            // 
            this.lbTopping5.AutoSize = true;
            this.lbTopping5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTopping5.Location = new System.Drawing.Point(160, 234);
            this.lbTopping5.Name = "lbTopping5";
            this.lbTopping5.Size = new System.Drawing.Size(197, 29);
            this.lbTopping5.TabIndex = 17;
            this.lbTopping5.Text = "Thạch củ năng :";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(509, 178);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 22);
            this.textBox4.TabIndex = 16;
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Location = new System.Drawing.Point(383, 178);
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(120, 22);
            this.numericUpDown4.TabIndex = 15;
            // 
            // lbTopping4
            // 
            this.lbTopping4.AutoSize = true;
            this.lbTopping4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTopping4.Location = new System.Drawing.Point(160, 169);
            this.lbTopping4.Name = "lbTopping4";
            this.lbTopping4.Size = new System.Drawing.Size(135, 29);
            this.lbTopping4.TabIndex = 14;
            this.lbTopping4.Text = "Bánh flan :";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(509, 119);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 22);
            this.textBox3.TabIndex = 13;
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Location = new System.Drawing.Point(383, 118);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(120, 22);
            this.numericUpDown3.TabIndex = 12;
            // 
            // lbTopping3
            // 
            this.lbTopping3.AutoSize = true;
            this.lbTopping3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTopping3.Location = new System.Drawing.Point(160, 112);
            this.lbTopping3.Name = "lbTopping3";
            this.lbTopping3.Size = new System.Drawing.Size(205, 29);
            this.lbTopping3.TabIndex = 11;
            this.lbTopping3.Text = "Trân châu vàng :";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(509, 63);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 10;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(383, 66);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(120, 22);
            this.numericUpDown2.TabIndex = 9;
            this.numericUpDown2.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // lbTopping2
            // 
            this.lbTopping2.AutoSize = true;
            this.lbTopping2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTopping2.Location = new System.Drawing.Point(160, 58);
            this.lbTopping2.Name = "lbTopping2";
            this.lbTopping2.Size = new System.Drawing.Size(205, 29);
            this.lbTopping2.TabIndex = 8;
            this.lbTopping2.Text = "Trân châu tuyết :";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(509, 13);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 7;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(383, 14);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 22);
            this.numericUpDown1.TabIndex = 6;
            // 
            // lbTopping1
            // 
            this.lbTopping1.AutoSize = true;
            this.lbTopping1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTopping1.Location = new System.Drawing.Point(160, 7);
            this.lbTopping1.Name = "lbTopping1";
            this.lbTopping1.Size = new System.Drawing.Size(194, 29);
            this.lbTopping1.TabIndex = 4;
            this.lbTopping1.Text = "Trân châu đen :";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnSizeL);
            this.panel5.Controls.Add(this.btnSizeM);
            this.panel5.Controls.Add(this.lbSize);
            this.panel5.Controls.Add(this.btnSizeS);
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(154, 440);
            this.panel5.TabIndex = 3;
            // 
            // btnSizeL
            // 
            this.btnSizeL.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSizeL.Location = new System.Drawing.Point(22, 269);
            this.btnSizeL.Name = "btnSizeL";
            this.btnSizeL.Size = new System.Drawing.Size(124, 57);
            this.btnSizeL.TabIndex = 6;
            this.btnSizeL.Text = "L";
            this.btnSizeL.UseVisualStyleBackColor = true;
            // 
            // btnSizeM
            // 
            this.btnSizeM.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSizeM.Location = new System.Drawing.Point(22, 146);
            this.btnSizeM.Name = "btnSizeM";
            this.btnSizeM.Size = new System.Drawing.Size(124, 57);
            this.btnSizeM.TabIndex = 5;
            this.btnSizeM.Text = "M";
            this.btnSizeM.UseVisualStyleBackColor = true;
            // 
            // lbSize
            // 
            this.lbSize.AutoSize = true;
            this.lbSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSize.Location = new System.Drawing.Point(3, 0);
            this.lbSize.Name = "lbSize";
            this.lbSize.Size = new System.Drawing.Size(130, 32);
            this.lbSize.TabIndex = 4;
            this.lbSize.Text = "Kích Cở:";
            // 
            // btnSizeS
            // 
            this.btnSizeS.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSizeS.Location = new System.Drawing.Point(22, 56);
            this.btnSizeS.Name = "btnSizeS";
            this.btnSizeS.Size = new System.Drawing.Size(124, 57);
            this.btnSizeS.TabIndex = 3;
            this.btnSizeS.Text = "S";
            this.btnSizeS.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.pnPercentIce);
            this.panel4.Controls.Add(this.pnPercentSugar);
            this.panel4.Controls.Add(this.lbIce);
            this.panel4.Controls.Add(this.lbSugar);
            this.panel4.Location = new System.Drawing.Point(655, 1);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(161, 446);
            this.panel4.TabIndex = 2;
            // 
            // pnPercentIce
            // 
            this.pnPercentIce.Controls.Add(this.rdbPercentIce3);
            this.pnPercentIce.Controls.Add(this.rdbPercentIce2);
            this.pnPercentIce.Controls.Add(this.rdbPercentIce1);
            this.pnPercentIce.Location = new System.Drawing.Point(0, 258);
            this.pnPercentIce.Name = "pnPercentIce";
            this.pnPercentIce.Size = new System.Drawing.Size(158, 154);
            this.pnPercentIce.TabIndex = 16;
            // 
            // rdbPercentIce3
            // 
            this.rdbPercentIce3.AutoSize = true;
            this.rdbPercentIce3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbPercentIce3.Location = new System.Drawing.Point(18, 78);
            this.rdbPercentIce3.Name = "rdbPercentIce3";
            this.rdbPercentIce3.Size = new System.Drawing.Size(125, 33);
            this.rdbPercentIce3.TabIndex = 9;
            this.rdbPercentIce3.TabStop = true;
            this.rdbPercentIce3.Text = "Đá riêng";
            this.rdbPercentIce3.UseVisualStyleBackColor = true;
            // 
            // rdbPercentIce2
            // 
            this.rdbPercentIce2.AutoSize = true;
            this.rdbPercentIce2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbPercentIce2.Location = new System.Drawing.Point(18, 39);
            this.rdbPercentIce2.Name = "rdbPercentIce2";
            this.rdbPercentIce2.Size = new System.Drawing.Size(82, 33);
            this.rdbPercentIce2.TabIndex = 8;
            this.rdbPercentIce2.TabStop = true;
            this.rdbPercentIce2.Text = "50%";
            this.rdbPercentIce2.UseVisualStyleBackColor = true;
            // 
            // rdbPercentIce1
            // 
            this.rdbPercentIce1.AutoSize = true;
            this.rdbPercentIce1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbPercentIce1.Location = new System.Drawing.Point(18, 3);
            this.rdbPercentIce1.Name = "rdbPercentIce1";
            this.rdbPercentIce1.Size = new System.Drawing.Size(95, 33);
            this.rdbPercentIce1.TabIndex = 7;
            this.rdbPercentIce1.TabStop = true;
            this.rdbPercentIce1.Text = "100%";
            this.rdbPercentIce1.UseVisualStyleBackColor = true;
            // 
            // pnPercentSugar
            // 
            this.pnPercentSugar.Controls.Add(this.rdbPercentSugar4);
            this.pnPercentSugar.Controls.Add(this.rdbPercentSugar3);
            this.pnPercentSugar.Controls.Add(this.rdbPercentSugar2);
            this.pnPercentSugar.Controls.Add(this.rdbPercentSugar1);
            this.pnPercentSugar.Location = new System.Drawing.Point(0, 40);
            this.pnPercentSugar.Name = "pnPercentSugar";
            this.pnPercentSugar.Size = new System.Drawing.Size(158, 166);
            this.pnPercentSugar.TabIndex = 15;
            // 
            // rdbPercentSugar4
            // 
            this.rdbPercentSugar4.AutoSize = true;
            this.rdbPercentSugar4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbPercentSugar4.Location = new System.Drawing.Point(18, 117);
            this.rdbPercentSugar4.Name = "rdbPercentSugar4";
            this.rdbPercentSugar4.Size = new System.Drawing.Size(82, 33);
            this.rdbPercentSugar4.TabIndex = 10;
            this.rdbPercentSugar4.TabStop = true;
            this.rdbPercentSugar4.Text = "30%";
            this.rdbPercentSugar4.UseVisualStyleBackColor = true;
            // 
            // rdbPercentSugar3
            // 
            this.rdbPercentSugar3.AutoSize = true;
            this.rdbPercentSugar3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbPercentSugar3.Location = new System.Drawing.Point(18, 78);
            this.rdbPercentSugar3.Name = "rdbPercentSugar3";
            this.rdbPercentSugar3.Size = new System.Drawing.Size(82, 33);
            this.rdbPercentSugar3.TabIndex = 9;
            this.rdbPercentSugar3.TabStop = true;
            this.rdbPercentSugar3.Text = "50%";
            this.rdbPercentSugar3.UseVisualStyleBackColor = true;
            // 
            // rdbPercentSugar2
            // 
            this.rdbPercentSugar2.AutoSize = true;
            this.rdbPercentSugar2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbPercentSugar2.Location = new System.Drawing.Point(18, 39);
            this.rdbPercentSugar2.Name = "rdbPercentSugar2";
            this.rdbPercentSugar2.Size = new System.Drawing.Size(82, 33);
            this.rdbPercentSugar2.TabIndex = 8;
            this.rdbPercentSugar2.TabStop = true;
            this.rdbPercentSugar2.Text = "70%";
            this.rdbPercentSugar2.UseVisualStyleBackColor = true;
            // 
            // rdbPercentSugar1
            // 
            this.rdbPercentSugar1.AutoSize = true;
            this.rdbPercentSugar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbPercentSugar1.Location = new System.Drawing.Point(18, 3);
            this.rdbPercentSugar1.Name = "rdbPercentSugar1";
            this.rdbPercentSugar1.Size = new System.Drawing.Size(95, 33);
            this.rdbPercentSugar1.TabIndex = 7;
            this.rdbPercentSugar1.TabStop = true;
            this.rdbPercentSugar1.Text = "100%";
            this.rdbPercentSugar1.UseVisualStyleBackColor = true;
            // 
            // lbIce
            // 
            this.lbIce.AutoSize = true;
            this.lbIce.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbIce.Location = new System.Drawing.Point(10, 226);
            this.lbIce.Name = "lbIce";
            this.lbIce.Size = new System.Drawing.Size(111, 29);
            this.lbIce.TabIndex = 11;
            this.lbIce.Text = "Mức đá :";
            // 
            // lbSugar
            // 
            this.lbSugar.AutoSize = true;
            this.lbSugar.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSugar.Location = new System.Drawing.Point(3, 8);
            this.lbSugar.Name = "lbSugar";
            this.lbSugar.Size = new System.Drawing.Size(155, 29);
            this.lbSugar.TabIndex = 6;
            this.lbSugar.Text = "Mức đường :";
            // 
            // btnConfirm
            // 
            this.btnConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirm.Location = new System.Drawing.Point(640, 462);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(173, 42);
            this.btnConfirm.TabIndex = 15;
            this.btnConfirm.Text = "Xác nhận";
            this.btnConfirm.UseVisualStyleBackColor = true;
            // 
            // DetailMilkTea
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(817, 507);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Name = "DetailMilkTea";
            this.Text = "DetailMilkTea";
            this.Load += new System.EventHandler(this.DetailMilkTea_Load);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.pnPercentIce.ResumeLayout(false);
            this.pnPercentIce.PerformLayout();
            this.pnPercentSugar.ResumeLayout(false);
            this.pnPercentSugar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbSize;
        private System.Windows.Forms.Button btnSizeS;
        private System.Windows.Forms.Label lbSugar;
        private System.Windows.Forms.Label lbIce;
        private System.Windows.Forms.RadioButton rdbPercentSugar4;
        private System.Windows.Forms.RadioButton rdbPercentSugar3;
        private System.Windows.Forms.RadioButton rdbPercentSugar2;
        private System.Windows.Forms.RadioButton rdbPercentSugar1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label lbTopping1;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.Label lbTopping4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.Label lbTopping3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Label lbTopping2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.NumericUpDown numericUpDown7;
        private System.Windows.Forms.Label lbTopping7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.NumericUpDown numericUpDown6;
        private System.Windows.Forms.Label lbTopping6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.NumericUpDown numericUpDown5;
        private System.Windows.Forms.Label lbTopping5;
        private System.Windows.Forms.Button btnSizeL;
        private System.Windows.Forms.Button btnSizeM;
        private System.Windows.Forms.Panel pnPercentIce;
        private System.Windows.Forms.RadioButton rdbPercentIce3;
        private System.Windows.Forms.RadioButton rdbPercentIce2;
        private System.Windows.Forms.RadioButton rdbPercentIce1;
        private System.Windows.Forms.Panel pnPercentSugar;
    }
}