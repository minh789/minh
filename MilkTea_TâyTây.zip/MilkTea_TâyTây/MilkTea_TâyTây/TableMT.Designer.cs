﻿namespace MilkTea_TâyTây
{
    partial class TableMT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TableMT));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ngườiDùngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thuChiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hóaĐơnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.khoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.flpTable = new System.Windows.Forms.FlowLayoutPanel();
            this.btnTable1 = new System.Windows.Forms.Button();
            this.btnTable2 = new System.Windows.Forms.Button();
            this.btnTable3 = new System.Windows.Forms.Button();
            this.btnTable4 = new System.Windows.Forms.Button();
            this.btnTable5 = new System.Windows.Forms.Button();
            this.btnTable6 = new System.Windows.Forms.Button();
            this.btnTable7 = new System.Windows.Forms.Button();
            this.btnTable8 = new System.Windows.Forms.Button();
            this.btnTable9 = new System.Windows.Forms.Button();
            this.btnTable10 = new System.Windows.Forms.Button();
            this.btnTable11 = new System.Windows.Forms.Button();
            this.btnTable12 = new System.Windows.Forms.Button();
            this.btnTable13 = new System.Windows.Forms.Button();
            this.btnTable14 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.flpTable.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.adminToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1115, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ngườiDùngToolStripMenuItem,
            this.thuChiToolStripMenuItem,
            this.hóaĐơnToolStripMenuItem,
            this.khoToolStripMenuItem,
            this.menuToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(90, 24);
            this.toolStripMenuItem1.Text = "Danh Mục";
            // 
            // ngườiDùngToolStripMenuItem
            // 
            this.ngườiDùngToolStripMenuItem.Name = "ngườiDùngToolStripMenuItem";
            this.ngườiDùngToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.ngườiDùngToolStripMenuItem.Text = "Nhân Viên";
            // 
            // thuChiToolStripMenuItem
            // 
            this.thuChiToolStripMenuItem.Name = "thuChiToolStripMenuItem";
            this.thuChiToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.thuChiToolStripMenuItem.Text = "Thu Chi";
            // 
            // hóaĐơnToolStripMenuItem
            // 
            this.hóaĐơnToolStripMenuItem.Name = "hóaĐơnToolStripMenuItem";
            this.hóaĐơnToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.hóaĐơnToolStripMenuItem.Text = "Hóa Đơn";
            // 
            // khoToolStripMenuItem
            // 
            this.khoToolStripMenuItem.Name = "khoToolStripMenuItem";
            this.khoToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.khoToolStripMenuItem.Text = "Kho";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.menuToolStripMenuItem.Text = "Menu";
            // 
            // adminToolStripMenuItem
            // 
            this.adminToolStripMenuItem.Name = "adminToolStripMenuItem";
            this.adminToolStripMenuItem.Size = new System.Drawing.Size(67, 24);
            this.adminToolStripMenuItem.Text = "Admin";
            this.adminToolStripMenuItem.Click += new System.EventHandler(this.adminToolStripMenuItem_Click);
            // 
            // flpTable
            // 
            this.flpTable.AutoScroll = true;
            this.flpTable.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.ftable__office_;
            this.flpTable.Controls.Add(this.btnTable1);
            this.flpTable.Controls.Add(this.btnTable2);
            this.flpTable.Controls.Add(this.btnTable3);
            this.flpTable.Controls.Add(this.btnTable4);
            this.flpTable.Controls.Add(this.btnTable5);
            this.flpTable.Controls.Add(this.btnTable6);
            this.flpTable.Controls.Add(this.btnTable7);
            this.flpTable.Controls.Add(this.btnTable8);
            this.flpTable.Controls.Add(this.btnTable9);
            this.flpTable.Controls.Add(this.btnTable10);
            this.flpTable.Controls.Add(this.btnTable11);
            this.flpTable.Controls.Add(this.btnTable12);
            this.flpTable.Controls.Add(this.btnTable13);
            this.flpTable.Controls.Add(this.btnTable14);
            this.flpTable.Location = new System.Drawing.Point(-1, 31);
            this.flpTable.Name = "flpTable";
            this.flpTable.Size = new System.Drawing.Size(1126, 541);
            this.flpTable.TabIndex = 0;
            // 
            // btnTable1
            // 
            this.btnTable1.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.table;
            this.btnTable1.Font = new System.Drawing.Font("Times New Roman", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTable1.ForeColor = System.Drawing.Color.Red;
            this.btnTable1.Location = new System.Drawing.Point(3, 3);
            this.btnTable1.Name = "btnTable1";
            this.btnTable1.Size = new System.Drawing.Size(152, 218);
            this.btnTable1.TabIndex = 2;
            this.btnTable1.Text = "Bàn 1";
            this.btnTable1.UseVisualStyleBackColor = true;
            this.btnTable1.Click += new System.EventHandler(this.btnTable1_Click);
            // 
            // btnTable2
            // 
            this.btnTable2.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.table;
            this.btnTable2.Font = new System.Drawing.Font("Times New Roman", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTable2.ForeColor = System.Drawing.Color.Red;
            this.btnTable2.Location = new System.Drawing.Point(161, 3);
            this.btnTable2.Name = "btnTable2";
            this.btnTable2.Size = new System.Drawing.Size(152, 218);
            this.btnTable2.TabIndex = 3;
            this.btnTable2.Text = "Bàn 2";
            this.btnTable2.UseVisualStyleBackColor = true;
            this.btnTable2.Click += new System.EventHandler(this.btnTable2_Click);
            // 
            // btnTable3
            // 
            this.btnTable3.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.table;
            this.btnTable3.Font = new System.Drawing.Font("Times New Roman", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTable3.ForeColor = System.Drawing.Color.Red;
            this.btnTable3.Location = new System.Drawing.Point(319, 3);
            this.btnTable3.Name = "btnTable3";
            this.btnTable3.Size = new System.Drawing.Size(152, 218);
            this.btnTable3.TabIndex = 4;
            this.btnTable3.Text = "Bàn 3";
            this.btnTable3.UseVisualStyleBackColor = true;
            this.btnTable3.Click += new System.EventHandler(this.btnTable3_Click);
            // 
            // btnTable4
            // 
            this.btnTable4.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.table;
            this.btnTable4.Font = new System.Drawing.Font("Times New Roman", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTable4.ForeColor = System.Drawing.Color.Red;
            this.btnTable4.Location = new System.Drawing.Point(477, 3);
            this.btnTable4.Name = "btnTable4";
            this.btnTable4.Size = new System.Drawing.Size(152, 218);
            this.btnTable4.TabIndex = 5;
            this.btnTable4.Text = "Bàn 4";
            this.btnTable4.UseVisualStyleBackColor = true;
            this.btnTable4.Click += new System.EventHandler(this.btnTable4_Click);
            // 
            // btnTable5
            // 
            this.btnTable5.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.table;
            this.btnTable5.Font = new System.Drawing.Font("Times New Roman", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTable5.ForeColor = System.Drawing.Color.Red;
            this.btnTable5.Location = new System.Drawing.Point(635, 3);
            this.btnTable5.Name = "btnTable5";
            this.btnTable5.Size = new System.Drawing.Size(152, 218);
            this.btnTable5.TabIndex = 6;
            this.btnTable5.Tag = " ";
            this.btnTable5.Text = "Bàn5";
            this.btnTable5.UseVisualStyleBackColor = true;
            this.btnTable5.Click += new System.EventHandler(this.btnTable5_Click);
            // 
            // btnTable6
            // 
            this.btnTable6.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.table;
            this.btnTable6.Font = new System.Drawing.Font("Times New Roman", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTable6.ForeColor = System.Drawing.Color.Red;
            this.btnTable6.Location = new System.Drawing.Point(793, 3);
            this.btnTable6.Name = "btnTable6";
            this.btnTable6.Size = new System.Drawing.Size(152, 218);
            this.btnTable6.TabIndex = 7;
            this.btnTable6.Text = "Bàn 6";
            this.btnTable6.UseVisualStyleBackColor = true;
            this.btnTable6.Click += new System.EventHandler(this.btnTable6_Click);
            // 
            // btnTable7
            // 
            this.btnTable7.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.table;
            this.btnTable7.Font = new System.Drawing.Font("Times New Roman", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTable7.ForeColor = System.Drawing.Color.Red;
            this.btnTable7.Location = new System.Drawing.Point(951, 3);
            this.btnTable7.Name = "btnTable7";
            this.btnTable7.Size = new System.Drawing.Size(152, 218);
            this.btnTable7.TabIndex = 8;
            this.btnTable7.Text = "Bàn 7";
            this.btnTable7.UseVisualStyleBackColor = true;
            this.btnTable7.Click += new System.EventHandler(this.btnTable7_Click);
            // 
            // btnTable8
            // 
            this.btnTable8.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.table;
            this.btnTable8.Font = new System.Drawing.Font("Times New Roman", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTable8.ForeColor = System.Drawing.Color.Red;
            this.btnTable8.Location = new System.Drawing.Point(3, 227);
            this.btnTable8.Name = "btnTable8";
            this.btnTable8.Size = new System.Drawing.Size(152, 218);
            this.btnTable8.TabIndex = 9;
            this.btnTable8.Text = "Bàn 8";
            this.btnTable8.UseVisualStyleBackColor = true;
            this.btnTable8.Click += new System.EventHandler(this.btnTable8_Click);
            // 
            // btnTable9
            // 
            this.btnTable9.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.table;
            this.btnTable9.Font = new System.Drawing.Font("Times New Roman", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTable9.ForeColor = System.Drawing.Color.Red;
            this.btnTable9.Location = new System.Drawing.Point(161, 227);
            this.btnTable9.Name = "btnTable9";
            this.btnTable9.Size = new System.Drawing.Size(152, 218);
            this.btnTable9.TabIndex = 10;
            this.btnTable9.Text = "Bàn 9";
            this.btnTable9.UseVisualStyleBackColor = true;
            this.btnTable9.Click += new System.EventHandler(this.btnTable9_Click);
            // 
            // btnTable10
            // 
            this.btnTable10.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.table;
            this.btnTable10.Font = new System.Drawing.Font("Times New Roman", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTable10.ForeColor = System.Drawing.Color.Red;
            this.btnTable10.Location = new System.Drawing.Point(319, 227);
            this.btnTable10.Name = "btnTable10";
            this.btnTable10.Size = new System.Drawing.Size(152, 218);
            this.btnTable10.TabIndex = 11;
            this.btnTable10.Text = "Bàn 10";
            this.btnTable10.UseVisualStyleBackColor = true;
            this.btnTable10.Click += new System.EventHandler(this.btnTable10_Click);
            // 
            // btnTable11
            // 
            this.btnTable11.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.table;
            this.btnTable11.Font = new System.Drawing.Font("Times New Roman", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTable11.ForeColor = System.Drawing.Color.Red;
            this.btnTable11.Location = new System.Drawing.Point(477, 227);
            this.btnTable11.Name = "btnTable11";
            this.btnTable11.Size = new System.Drawing.Size(152, 218);
            this.btnTable11.TabIndex = 12;
            this.btnTable11.Text = "Bàn 11";
            this.btnTable11.UseVisualStyleBackColor = true;
            this.btnTable11.Click += new System.EventHandler(this.btnTable11_Click);
            // 
            // btnTable12
            // 
            this.btnTable12.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.table;
            this.btnTable12.Font = new System.Drawing.Font("Times New Roman", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTable12.ForeColor = System.Drawing.Color.Red;
            this.btnTable12.Location = new System.Drawing.Point(635, 227);
            this.btnTable12.Name = "btnTable12";
            this.btnTable12.Size = new System.Drawing.Size(152, 218);
            this.btnTable12.TabIndex = 13;
            this.btnTable12.Text = "Bàn 12";
            this.btnTable12.UseVisualStyleBackColor = true;
            this.btnTable12.Click += new System.EventHandler(this.btnTable12_Click);
            // 
            // btnTable13
            // 
            this.btnTable13.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.table;
            this.btnTable13.Font = new System.Drawing.Font("Times New Roman", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTable13.ForeColor = System.Drawing.Color.Red;
            this.btnTable13.Location = new System.Drawing.Point(793, 227);
            this.btnTable13.Name = "btnTable13";
            this.btnTable13.Size = new System.Drawing.Size(152, 218);
            this.btnTable13.TabIndex = 14;
            this.btnTable13.Text = "Bàn 13";
            this.btnTable13.UseVisualStyleBackColor = true;
            this.btnTable13.Click += new System.EventHandler(this.btnTable13_Click);
            // 
            // btnTable14
            // 
            this.btnTable14.BackgroundImage = global::MilkTea_TâyTây.Properties.Resources.table;
            this.btnTable14.Font = new System.Drawing.Font("Times New Roman", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTable14.ForeColor = System.Drawing.Color.Red;
            this.btnTable14.Location = new System.Drawing.Point(951, 227);
            this.btnTable14.Name = "btnTable14";
            this.btnTable14.Size = new System.Drawing.Size(152, 218);
            this.btnTable14.TabIndex = 15;
            this.btnTable14.Text = "Bàn 14";
            this.btnTable14.UseVisualStyleBackColor = true;
            this.btnTable14.Click += new System.EventHandler(this.btnTable14_Click);
            // 
            // TableMT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1115, 528);
            this.Controls.Add(this.flpTable);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TableMT";
            this.Text = " Bàn";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.flpTable.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ngườiDùngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thuChiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hóaĐơnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem khoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem;
        private System.Windows.Forms.Button btnTable14;
        private System.Windows.Forms.Button btnTable13;
        private System.Windows.Forms.Button btnTable12;
        private System.Windows.Forms.Button btnTable11;
        private System.Windows.Forms.Button btnTable10;
        private System.Windows.Forms.Button btnTable9;
        private System.Windows.Forms.Button btnTable8;
        private System.Windows.Forms.Button btnTable7;
        private System.Windows.Forms.Button btnTable6;
        private System.Windows.Forms.Button btnTable5;
        private System.Windows.Forms.Button btnTable4;
        private System.Windows.Forms.Button btnTable3;
        private System.Windows.Forms.Button btnTable2;
        private System.Windows.Forms.Button btnTable1;
        private System.Windows.Forms.FlowLayoutPanel flpTable;
    }
}