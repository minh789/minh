﻿namespace MilkTea_TâyTây
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.btnCombineTable = new System.Windows.Forms.Button();
            this.pnfunction = new System.Windows.Forms.Panel();
            this.btnFind = new System.Windows.Forms.Button();
            this.btnSeparateTable = new System.Windows.Forms.Button();
            this.btnBill = new System.Windows.Forms.Button();
            this.lvBill = new System.Windows.Forms.ListView();
            this.flpBill = new System.Windows.Forms.FlowLayoutPanel();
            this.pnMenu = new System.Windows.Forms.Panel();
            this.pnCategory = new System.Windows.Forms.Panel();
            this.btnFreshMilk = new System.Windows.Forms.Button();
            this.btnSpecial = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnMilkTea = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pnfunction.SuspendLayout();
            this.pnMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCombineTable
            // 
            this.btnCombineTable.BackColor = System.Drawing.Color.LightCoral;
            this.btnCombineTable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCombineTable.ForeColor = System.Drawing.Color.Black;
            this.btnCombineTable.Location = new System.Drawing.Point(0, 487);
            this.btnCombineTable.Name = "btnCombineTable";
            this.btnCombineTable.Size = new System.Drawing.Size(134, 39);
            this.btnCombineTable.TabIndex = 0;
            this.btnCombineTable.Text = "Gộp bàn";
            this.btnCombineTable.UseVisualStyleBackColor = false;
            // 
            // pnfunction
            // 
            this.pnfunction.Controls.Add(this.btnFind);
            this.pnfunction.Controls.Add(this.btnSeparateTable);
            this.pnfunction.Controls.Add(this.btnBill);
            this.pnfunction.Controls.Add(this.btnCombineTable);
            this.pnfunction.Location = new System.Drawing.Point(3, 2);
            this.pnfunction.Name = "pnfunction";
            this.pnfunction.Size = new System.Drawing.Size(134, 559);
            this.pnfunction.TabIndex = 0;
            // 
            // btnFind
            // 
            this.btnFind.BackColor = System.Drawing.Color.Lime;
            this.btnFind.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFind.ForeColor = System.Drawing.Color.DarkRed;
            this.btnFind.Location = new System.Drawing.Point(3, 278);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(131, 39);
            this.btnFind.TabIndex = 3;
            this.btnFind.Text = "Tìm kiếm";
            this.btnFind.UseVisualStyleBackColor = false;
            // 
            // btnSeparateTable
            // 
            this.btnSeparateTable.BackColor = System.Drawing.Color.LightCoral;
            this.btnSeparateTable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSeparateTable.ForeColor = System.Drawing.Color.Black;
            this.btnSeparateTable.Location = new System.Drawing.Point(-3, 417);
            this.btnSeparateTable.Name = "btnSeparateTable";
            this.btnSeparateTable.Size = new System.Drawing.Size(137, 39);
            this.btnSeparateTable.TabIndex = 2;
            this.btnSeparateTable.Text = "Tách bàn";
            this.btnSeparateTable.UseVisualStyleBackColor = false;
            // 
            // btnBill
            // 
            this.btnBill.BackColor = System.Drawing.Color.Cyan;
            this.btnBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBill.ForeColor = System.Drawing.Color.OrangeRed;
            this.btnBill.Location = new System.Drawing.Point(0, 351);
            this.btnBill.Name = "btnBill";
            this.btnBill.Size = new System.Drawing.Size(131, 39);
            this.btnBill.TabIndex = 1;
            this.btnBill.Text = "In hóa đơn";
            this.btnBill.UseVisualStyleBackColor = false;
            // 
            // lvBill
            // 
            this.lvBill.HideSelection = false;
            this.lvBill.Location = new System.Drawing.Point(143, 5);
            this.lvBill.Name = "lvBill";
            this.lvBill.Size = new System.Drawing.Size(180, 505);
            this.lvBill.TabIndex = 0;
            this.lvBill.UseCompatibleStateImageBehavior = false;
            // 
            // flpBill
            // 
            this.flpBill.Location = new System.Drawing.Point(140, -1);
            this.flpBill.Name = "flpBill";
            this.flpBill.Size = new System.Drawing.Size(170, 511);
            this.flpBill.TabIndex = 1;
            // 
            // pnMenu
            // 
            this.pnMenu.Controls.Add(this.pnCategory);
            this.pnMenu.Controls.Add(this.btnFreshMilk);
            this.pnMenu.Controls.Add(this.btnSpecial);
            this.pnMenu.Controls.Add(this.button2);
            this.pnMenu.Controls.Add(this.btnMilkTea);
            this.pnMenu.Location = new System.Drawing.Point(326, 2);
            this.pnMenu.Name = "pnMenu";
            this.pnMenu.Size = new System.Drawing.Size(974, 559);
            this.pnMenu.TabIndex = 2;
            // 
            // pnCategory
            // 
            this.pnCategory.Location = new System.Drawing.Point(152, 3);
            this.pnCategory.Name = "pnCategory";
            this.pnCategory.Size = new System.Drawing.Size(892, 556);
            this.pnCategory.TabIndex = 4;
            // 
            // btnFreshMilk
            // 
            this.btnFreshMilk.BackColor = System.Drawing.Color.Yellow;
            this.btnFreshMilk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFreshMilk.ForeColor = System.Drawing.Color.Black;
            this.btnFreshMilk.Location = new System.Drawing.Point(0, 351);
            this.btnFreshMilk.Name = "btnFreshMilk";
            this.btnFreshMilk.Size = new System.Drawing.Size(146, 56);
            this.btnFreshMilk.TabIndex = 3;
            this.btnFreshMilk.Text = "Sữa Tươi";
            this.btnFreshMilk.UseVisualStyleBackColor = false;
            this.btnFreshMilk.Click += new System.EventHandler(this.btnFreshMilk_Click);
            // 
            // btnSpecial
            // 
            this.btnSpecial.BackColor = System.Drawing.Color.Yellow;
            this.btnSpecial.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSpecial.ForeColor = System.Drawing.Color.Black;
            this.btnSpecial.Location = new System.Drawing.Point(3, 198);
            this.btnSpecial.Name = "btnSpecial";
            this.btnSpecial.Size = new System.Drawing.Size(143, 59);
            this.btnSpecial.TabIndex = 2;
            this.btnSpecial.Text = "Đặc biệt";
            this.btnSpecial.UseVisualStyleBackColor = false;
            this.btnSpecial.Click += new System.EventHandler(this.btnGreentea_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(166, 144);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(8, 8);
            this.button2.TabIndex = 1;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // btnMilkTea
            // 
            this.btnMilkTea.BackColor = System.Drawing.Color.Yellow;
            this.btnMilkTea.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMilkTea.ForeColor = System.Drawing.Color.Black;
            this.btnMilkTea.Location = new System.Drawing.Point(3, 34);
            this.btnMilkTea.Name = "btnMilkTea";
            this.btnMilkTea.Size = new System.Drawing.Size(143, 55);
            this.btnMilkTea.TabIndex = 0;
            this.btnMilkTea.Text = "Trà Sữa";
            this.btnMilkTea.UseVisualStyleBackColor = false;
            this.btnMilkTea.Click += new System.EventHandler(this.btnMilkTea_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(135, 531);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tổng tiền :";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(247, 531);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(73, 22);
            this.textBox1.TabIndex = 5;
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1300, 565);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lvBill);
            this.Controls.Add(this.pnMenu);
            this.Controls.Add(this.pnfunction);
            this.Controls.Add(this.flpBill);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Menu";
            this.Text = "Thực đơn ";
            this.pnfunction.ResumeLayout(false);
            this.pnMenu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnCombineTable;
        private System.Windows.Forms.Panel pnfunction;
        private System.Windows.Forms.ListView lvBill;
        private System.Windows.Forms.FlowLayoutPanel flpBill;
        private System.Windows.Forms.Panel pnMenu;
        private System.Windows.Forms.Button btnFreshMilk;
        private System.Windows.Forms.Button btnSpecial;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnMilkTea;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.Button btnSeparateTable;
        private System.Windows.Forms.Button btnBill;
        private System.Windows.Forms.Panel pnCategory;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
    }
}